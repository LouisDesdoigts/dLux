# dLux

dLux: Taking derivatives through Light

'Optical systems as a Neural Network'

Google colab showing deployment onto GPU:
https://colab.research.google.com/drive/1Dz5NdRhtbGOzPl7jlIn5JvwNEQfaOq9Y?usp=sharing
